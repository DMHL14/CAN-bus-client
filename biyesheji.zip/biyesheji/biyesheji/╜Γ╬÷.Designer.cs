﻿namespace biyesheji
{
    partial class 解析
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_saveJX = new System.Windows.Forms.Button();
            this.button_JXstop = new System.Windows.Forms.Button();
            this.button_JXopen = new System.Windows.Forms.Button();
            this.button_DBC = new System.Windows.Forms.Button();
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.label_xieyi = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.message = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PGN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.frameType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataLength = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.frameData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column_XH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalFormat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startBit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalLen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalFactor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalOffset = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalMin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalMax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rawValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SignalNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_fanhui = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_SS = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.timerSS = new System.Windows.Forms.Timer(this.components);
            this.button_Reset = new System.Windows.Forms.Button();
            this.button_JXT = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_saveJX
            // 
            this.button_saveJX.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_saveJX.Location = new System.Drawing.Point(546, 15);
            this.button_saveJX.Name = "button_saveJX";
            this.button_saveJX.Size = new System.Drawing.Size(100, 29);
            this.button_saveJX.TabIndex = 61;
            this.button_saveJX.Text = "解析保存";
            this.button_saveJX.UseVisualStyleBackColor = true;
            this.button_saveJX.Click += new System.EventHandler(this.Button_saveJX_Click);
            // 
            // button_JXstop
            // 
            this.button_JXstop.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_JXstop.Location = new System.Drawing.Point(441, 15);
            this.button_JXstop.Name = "button_JXstop";
            this.button_JXstop.Size = new System.Drawing.Size(99, 29);
            this.button_JXstop.TabIndex = 62;
            this.button_JXstop.Text = "停止解析";
            this.button_JXstop.UseVisualStyleBackColor = true;
            this.button_JXstop.Click += new System.EventHandler(this.Button_JXstop_Click);
            // 
            // button_JXopen
            // 
            this.button_JXopen.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_JXopen.Location = new System.Drawing.Point(335, 15);
            this.button_JXopen.Name = "button_JXopen";
            this.button_JXopen.Size = new System.Drawing.Size(100, 29);
            this.button_JXopen.TabIndex = 60;
            this.button_JXopen.Text = "启动解析";
            this.button_JXopen.UseVisualStyleBackColor = true;
            this.button_JXopen.Click += new System.EventHandler(this.Button_JXopen_Click);
            // 
            // button_DBC
            // 
            this.button_DBC.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_DBC.Location = new System.Drawing.Point(12, 15);
            this.button_DBC.Name = "button_DBC";
            this.button_DBC.Size = new System.Drawing.Size(100, 29);
            this.button_DBC.TabIndex = 59;
            this.button_DBC.Text = "加载DBC文件";
            this.button_DBC.UseVisualStyleBackColor = true;
            this.button_DBC.Click += new System.EventHandler(this.Button1_Click);
            // 
            // ofd
            // 
            this.ofd.InitialDirectory = "d:\\\\";
            // 
            // label_xieyi
            // 
            this.label_xieyi.AutoSize = true;
            this.label_xieyi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label_xieyi.Location = new System.Drawing.Point(90, 468);
            this.label_xieyi.Name = "label_xieyi";
            this.label_xieyi.Size = new System.Drawing.Size(67, 15);
            this.label_xieyi.TabIndex = 65;
            this.label_xieyi.Text = "协议类型";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(9, 468);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 66;
            this.label1.Text = "协议类型:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.message,
            this.ID,
            this.PGN,
            this.frameType,
            this.dataLength,
            this.frameData,
            this.note});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 20;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(1276, 145);
            this.dataGridView1.TabIndex = 67;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellClick);
            // 
            // message
            // 
            this.message.HeaderText = "消息名";
            this.message.MinimumWidth = 6;
            this.message.Name = "message";
            this.message.ReadOnly = true;
            this.message.Width = 125;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 125;
            // 
            // PGN
            // 
            this.PGN.HeaderText = "PGN(H)";
            this.PGN.MinimumWidth = 6;
            this.PGN.Name = "PGN";
            this.PGN.ReadOnly = true;
            this.PGN.Width = 125;
            // 
            // frameType
            // 
            this.frameType.HeaderText = "帧类型";
            this.frameType.MinimumWidth = 6;
            this.frameType.Name = "frameType";
            this.frameType.ReadOnly = true;
            this.frameType.Width = 125;
            // 
            // dataLength
            // 
            this.dataLength.HeaderText = "信号数";
            this.dataLength.MinimumWidth = 6;
            this.dataLength.Name = "dataLength";
            this.dataLength.ReadOnly = true;
            this.dataLength.Width = 125;
            // 
            // frameData
            // 
            this.frameData.HeaderText = "帧数据";
            this.frameData.MinimumWidth = 6;
            this.frameData.Name = "frameData";
            this.frameData.ReadOnly = true;
            this.frameData.Width = 125;
            // 
            // note
            // 
            this.note.HeaderText = "注释";
            this.note.MinimumWidth = 6;
            this.note.Name = "note";
            this.note.ReadOnly = true;
            this.note.Width = 180;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column_XH,
            this.SignalID,
            this.SignalName,
            this.SignalFormat,
            this.SignalType,
            this.startBit,
            this.SignalLen,
            this.SignalFactor,
            this.SignalOffset,
            this.SignalMin,
            this.SignalMax,
            this.rawValue,
            this.SignalValue,
            this.SignalUnit,
            this.SignalNote});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 20;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(1276, 216);
            this.dataGridView2.TabIndex = 68;
            // 
            // Column_XH
            // 
            this.Column_XH.HeaderText = "序号";
            this.Column_XH.MinimumWidth = 6;
            this.Column_XH.Name = "Column_XH";
            this.Column_XH.Width = 80;
            // 
            // SignalID
            // 
            this.SignalID.HeaderText = "ID";
            this.SignalID.MinimumWidth = 6;
            this.SignalID.Name = "SignalID";
            this.SignalID.Width = 125;
            // 
            // SignalName
            // 
            this.SignalName.HeaderText = "信号名";
            this.SignalName.MinimumWidth = 6;
            this.SignalName.Name = "SignalName";
            this.SignalName.Width = 125;
            // 
            // SignalFormat
            // 
            this.SignalFormat.HeaderText = "格式";
            this.SignalFormat.MinimumWidth = 6;
            this.SignalFormat.Name = "SignalFormat";
            this.SignalFormat.Width = 60;
            // 
            // SignalType
            // 
            this.SignalType.HeaderText = "类型";
            this.SignalType.MinimumWidth = 6;
            this.SignalType.Name = "SignalType";
            this.SignalType.Width = 60;
            // 
            // startBit
            // 
            this.startBit.HeaderText = "起始位";
            this.startBit.MinimumWidth = 6;
            this.startBit.Name = "startBit";
            this.startBit.Width = 68;
            // 
            // SignalLen
            // 
            this.SignalLen.HeaderText = "位长度";
            this.SignalLen.MinimumWidth = 6;
            this.SignalLen.Name = "SignalLen";
            this.SignalLen.Width = 68;
            // 
            // SignalFactor
            // 
            this.SignalFactor.HeaderText = "转换因子";
            this.SignalFactor.MinimumWidth = 6;
            this.SignalFactor.Name = "SignalFactor";
            this.SignalFactor.Width = 125;
            // 
            // SignalOffset
            // 
            this.SignalOffset.HeaderText = "偏移量";
            this.SignalOffset.MinimumWidth = 6;
            this.SignalOffset.Name = "SignalOffset";
            this.SignalOffset.Width = 68;
            // 
            // SignalMin
            // 
            this.SignalMin.HeaderText = "最小值";
            this.SignalMin.MinimumWidth = 6;
            this.SignalMin.Name = "SignalMin";
            this.SignalMin.Width = 68;
            // 
            // SignalMax
            // 
            this.SignalMax.HeaderText = "最大值";
            this.SignalMax.MinimumWidth = 6;
            this.SignalMax.Name = "SignalMax";
            this.SignalMax.Width = 68;
            // 
            // rawValue
            // 
            this.rawValue.HeaderText = "原始值";
            this.rawValue.MinimumWidth = 6;
            this.rawValue.Name = "rawValue";
            this.rawValue.Width = 68;
            // 
            // SignalValue
            // 
            this.SignalValue.HeaderText = "实际值";
            this.SignalValue.MinimumWidth = 6;
            this.SignalValue.Name = "SignalValue";
            this.SignalValue.Width = 68;
            // 
            // SignalUnit
            // 
            this.SignalUnit.HeaderText = "单位";
            this.SignalUnit.MinimumWidth = 6;
            this.SignalUnit.Name = "SignalUnit";
            this.SignalUnit.Width = 50;
            // 
            // SignalNote
            // 
            this.SignalNote.HeaderText = "注释";
            this.SignalNote.MinimumWidth = 6;
            this.SignalNote.Name = "SignalNote";
            this.SignalNote.Width = 150;
            // 
            // button_fanhui
            // 
            this.button_fanhui.Location = new System.Drawing.Point(852, 15);
            this.button_fanhui.Name = "button_fanhui";
            this.button_fanhui.Size = new System.Drawing.Size(108, 29);
            this.button_fanhui.TabIndex = 70;
            this.button_fanhui.Text = "返回主界面";
            this.button_fanhui.UseVisualStyleBackColor = true;
            this.button_fanhui.Click += new System.EventHandler(this.Button_fanhui_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(12, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1276, 145);
            this.panel1.TabIndex = 71;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dataGridView2);
            this.panel2.Location = new System.Drawing.Point(12, 245);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1276, 216);
            this.panel2.TabIndex = 72;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(9, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 73;
            this.label2.Text = "加载协议";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(9, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 74;
            this.label3.Text = "解析结果";
            // 
            // comboBox_SS
            // 
            this.comboBox_SS.FormattingEnabled = true;
            this.comboBox_SS.Items.AddRange(new object[] {
            "非实时解析",
            "实时解析"});
            this.comboBox_SS.Location = new System.Drawing.Point(191, 15);
            this.comboBox_SS.Name = "comboBox_SS";
            this.comboBox_SS.Size = new System.Drawing.Size(121, 23);
            this.comboBox_SS.TabIndex = 80;
            this.comboBox_SS.SelectedIndexChanged += new System.EventHandler(this.ComboBox_SS_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(118, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 81;
            this.label4.Text = "解析模式";
            // 
            // timerSS
            // 
            this.timerSS.Interval = 1000;
            this.timerSS.Tick += new System.EventHandler(this.TimerSS_Tick);
            // 
            // button_Reset
            // 
            this.button_Reset.Location = new System.Drawing.Point(751, 15);
            this.button_Reset.Name = "button_Reset";
            this.button_Reset.Size = new System.Drawing.Size(95, 29);
            this.button_Reset.TabIndex = 82;
            this.button_Reset.Text = "复位";
            this.button_Reset.UseVisualStyleBackColor = true;
            this.button_Reset.Click += new System.EventHandler(this.Button_Reset_Click);
            // 
            // button_JXT
            // 
            this.button_JXT.Location = new System.Drawing.Point(652, 15);
            this.button_JXT.Name = "button_JXT";
            this.button_JXT.Size = new System.Drawing.Size(93, 29);
            this.button_JXT.TabIndex = 83;
            this.button_JXT.Text = "解析图";
            this.button_JXT.UseVisualStyleBackColor = true;
            this.button_JXT.Click += new System.EventHandler(this.Button_JXT_Click);
            // 
            // 解析
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1292, 492);
            this.Controls.Add(this.button_JXT);
            this.Controls.Add(this.button_Reset);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox_SS);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button_DBC);
            this.Controls.Add(this.label_xieyi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_JXstop);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_JXopen);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_fanhui);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_saveJX);
            this.Name = "解析";
            this.Text = "解析";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.解析_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.解析_FormClosed);
            this.Load += new System.EventHandler(this.解析_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_saveJX;
        private System.Windows.Forms.Button button_JXstop;
        private System.Windows.Forms.Button button_JXopen;
        private System.Windows.Forms.Button button_DBC;
        private System.Windows.Forms.OpenFileDialog ofd;
        private System.Windows.Forms.Label label_xieyi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button_fanhui;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn message;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PGN;
        private System.Windows.Forms.DataGridViewTextBoxColumn frameType;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataLength;
        private System.Windows.Forms.DataGridViewTextBoxColumn frameData;
        private System.Windows.Forms.DataGridViewTextBoxColumn note;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_XH;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalFormat;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalType;
        private System.Windows.Forms.DataGridViewTextBoxColumn startBit;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalLen;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalFactor;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalOffset;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalMin;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalMax;
        private System.Windows.Forms.DataGridViewTextBoxColumn rawValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn SignalNote;
        private System.Windows.Forms.ComboBox comboBox_SS;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timerSS;
        private System.Windows.Forms.Button button_Reset;
        private System.Windows.Forms.Button button_JXT;
    }
}