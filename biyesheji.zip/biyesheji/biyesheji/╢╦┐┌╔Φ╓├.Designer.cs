﻿namespace biyesheji
{
    partial class 端口设置
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.网络连接 = new System.Windows.Forms.RadioButton();
            this.USB连接 = new System.Windows.Forms.RadioButton();
            this.搜索 = new System.Windows.Forms.Button();
            this.刷新 = new System.Windows.Forms.Button();
            this.textBox网络 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.打开 = new System.Windows.Forms.Button();
            this.取消 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // 网络连接
            // 
            this.网络连接.AutoSize = true;
            this.网络连接.Location = new System.Drawing.Point(33, 73);
            this.网络连接.Name = "网络连接";
            this.网络连接.Size = new System.Drawing.Size(88, 19);
            this.网络连接.TabIndex = 0;
            this.网络连接.Text = "网络连接";
            this.网络连接.UseVisualStyleBackColor = true;
            this.网络连接.MouseClick += new System.Windows.Forms.MouseEventHandler(this.网络连接_MouseClick);
            // 
            // USB连接
            // 
            this.USB连接.AutoSize = true;
            this.USB连接.Location = new System.Drawing.Point(33, 119);
            this.USB连接.Name = "USB连接";
            this.USB连接.Size = new System.Drawing.Size(82, 19);
            this.USB连接.TabIndex = 1;
            this.USB连接.Text = "USB连接";
            this.USB连接.UseVisualStyleBackColor = true;
            this.USB连接.MouseClick += new System.Windows.Forms.MouseEventHandler(this.USB连接_MouseClick);
            // 
            // 搜索
            // 
            this.搜索.Enabled = false;
            this.搜索.Location = new System.Drawing.Point(450, 70);
            this.搜索.Name = "搜索";
            this.搜索.Size = new System.Drawing.Size(75, 27);
            this.搜索.TabIndex = 4;
            this.搜索.Text = "搜索";
            this.搜索.UseVisualStyleBackColor = true;
            // 
            // 刷新
            // 
            this.刷新.Enabled = false;
            this.刷新.Location = new System.Drawing.Point(450, 113);
            this.刷新.Name = "刷新";
            this.刷新.Size = new System.Drawing.Size(75, 25);
            this.刷新.TabIndex = 5;
            this.刷新.Text = "刷新";
            this.刷新.UseVisualStyleBackColor = true;
            // 
            // textBox网络
            // 
            this.textBox网络.Enabled = false;
            this.textBox网络.Location = new System.Drawing.Point(176, 72);
            this.textBox网络.Name = "textBox网络";
            this.textBox网络.Size = new System.Drawing.Size(222, 25);
            this.textBox网络.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(176, 115);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(222, 23);
            this.comboBox1.TabIndex = 7;
            // 
            // 打开
            // 
            this.打开.Location = new System.Drawing.Point(96, 158);
            this.打开.Name = "打开";
            this.打开.Size = new System.Drawing.Size(101, 46);
            this.打开.TabIndex = 9;
            this.打开.Text = "打开";
            this.打开.UseVisualStyleBackColor = true;
            this.打开.Click += new System.EventHandler(this.打开_Click);
            // 
            // 取消
            // 
            this.取消.Location = new System.Drawing.Point(328, 158);
            this.取消.Name = "取消";
            this.取消.Size = new System.Drawing.Size(94, 46);
            this.取消.TabIndex = 10;
            this.取消.Text = "取消";
            this.取消.UseVisualStyleBackColor = true;
            this.取消.Click += new System.EventHandler(this.取消_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // 端口设置
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 253);
            this.Controls.Add(this.取消);
            this.Controls.Add(this.打开);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox网络);
            this.Controls.Add(this.刷新);
            this.Controls.Add(this.搜索);
            this.Controls.Add(this.USB连接);
            this.Controls.Add(this.网络连接);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "端口设置";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "端口设置";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.端口设置_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton 网络连接;
        private System.Windows.Forms.RadioButton USB连接;
        private System.Windows.Forms.Button 搜索;
        private System.Windows.Forms.Button 刷新;
        private System.Windows.Forms.TextBox textBox网络;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button 打开;
        private System.Windows.Forms.Button 取消;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}