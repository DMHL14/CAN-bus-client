﻿using System;
using System.Windows.Forms;
using GCKJ;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Text;

namespace biyesheji
{
    public partial class 解析 : Form
    {
        //// 处理帧发送
        public void onsend(IntPtr ctx, IntPtr pojbj)
        {
            Ctx info = (Ctx)Marshal.PtrToStructure(ctx, typeof(Ctx));
            CAN_OBJ obj = (CAN_OBJ)Marshal.PtrToStructure(pojbj, typeof(CAN_OBJ));
            if (ECANDLL.Transmit(m_devInfo.nDevType, m_devInfo.nDevIndex, m_devInfo.nChIndex, ref obj, 1) == 0)
            {
                ;
            }
        }

        //此函数用以设置实际发送数据的回调函数, 涉及数据发送时必须设置，只需要设置一次
        [DllImport("LibDBCManager.dll")]
        static extern void DBC_SetSender(Int32 hDBC, Onsend sender, IntPtr ctx);

        [DllImport("LibDBCManager.dll")]
        static extern void DBC_SetOnMultiTransDoneFunc(Int32 hDBC, OnMultiTransDone func, IntPtr ctx);

        public static bool SSflag = false;           //实时解析标志
        public static bool JXingflag = true;        //正在解析标志
        public static bool DATASendOKflag = false;         //主界面报文已全部传递完毕标志
        public static bool JXOKflag =  false;      //解析完毕标志
       // public string filename;
        public static List<double> datavalue1 = new List<double>();            //存放解析后的值便于画图
        public static List<string> XuHao = new List<string>();                //存放解析后的值便于画图
        public static string num;                            //画图曲线数量
        public Ctx m_ctx;
        public DevInfo m_devInfo = new DevInfo();

        public System.IO.FileInfo info;
        private List<DBCMessage> m_vMsg = new List<DBCMessage>();

        public int HDBC { get; set; }

        //// 处理DBC
        public delegate void Onsend(IntPtr ctx, IntPtr pojbj);
        public delegate void OnMultiTransDone(IntPtr ctx, ref DBCMessage pMsg, ref Byte data, UInt16 nLen, Byte nDirection);


 


        public 解析()
        {
            InitializeComponent();
            HDBC = -1;
            m_devInfo.nDevType = SCADA.m_devtype;
            m_devInfo.nDevIndex = SCADA.m_devind;
            m_devInfo.nChIndex = SCADA.m_canind;
        }
        private void 解析_Load(object sender, EventArgs e)
        {
            //默认非实时解析
            comboBox_SS.SelectedIndex = 0;
            HDBC =DBCjiexi.DBC_Init();
            if (HDBC == -1)
            {
                MessageBox.Show("生成DBC句柄失败");
            }
            //Marshal.
            m_ctx.powner = this.Handle;
            m_ctx.devinfo = m_devInfo;

            IntPtr pt = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Ctx)));
            DBC_SetSender(HDBC, onsend, pt);
        }

        private unsafe void Button1_Click(object sender, EventArgs e)
        {
            ofd.InitialDirectory = @"C:\Users\pechc\Desktop";
            ofd.Filter = "DBC文件|*.dbc";
            ofd.RestoreDirectory = true;// *如果值为false，那么下一次选择文件的初始目录是上一次你选择的那个目录，
            ofd.FilterIndex = 1;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                _ = ofd.FileName;
                string strFile = Path.GetFullPath(ofd.FileName);//不能只取得路径
                if (strFile == null)
                {
                    MessageBox.Show("路径为空");
                    return;
                }
                try
                {
                    GCKJ.FileInfo fileInfo;
                    byte[] str = Encoding.Default.GetBytes(strFile);
                    Marshal.Copy(str, 0, (IntPtr)fileInfo.strFilePath, str.Length);
                    //Marshal.StructureToPtr(str, (IntPtr)fileInfo.strFilePath, true);
                    if (Path.GetFileNameWithoutExtension(ofd.FileName)== "j1939")
                    {
                        fileInfo.nType = ProtocolType.DBC_J1939;
                        label_xieyi.Text = "J1939";
                    }
                    else
                    {
                        fileInfo.nType = ProtocolType.DBC_CAN;
                        label_xieyi.Text = "CAN";
                    }

                    fileInfo.merge = 1;

                    if (!DBCjiexi.DBC_LoadFile(HDBC, ref fileInfo))
                    {
                        MessageBox.Show("加载文件错误");
                        return;
                    }
                    uint nCount =DBCjiexi.DBC_GetMessageCount(HDBC);
                    if (DBCjiexi.DBC_GetMessageCount(HDBC) == 0)
                    {
                        MessageBox.Show("文件中不含有消息");
                    }
                    ReadAllMessage();
                    dataGridView2.Rows.Clear();
                }
                catch (Exception)
                {
                    MessageBox.Show("加载失败");
                }
            }
        }

        public void ReadAllMessage()
        {

            IntPtr pt = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DBCMessage)));
            if (DBCjiexi.DBC_GetFirstMessage(HDBC, pt))
            {
                DBCMessage msg = (DBCMessage)Marshal.PtrToStructure(pt, typeof(DBCMessage));
                m_vMsg.Add(msg);
                int index1 = dataGridView1.Rows.Add();
                dataGridView1.Rows[index1].Cells[0].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.strName), @"\0", string.Empty);
                this.dataGridView1.Rows[index1].Cells[1].Value = msg.nID;
                if (msg.nExtend == 0)
                {
                    this.dataGridView1.Rows[index1].Cells[3].Value = "标准帧";
                }
                else
                {
                    this.dataGridView1.Rows[index1].Cells[3].Value = "扩展帧";
                }

                this.dataGridView1.Rows[index1].Cells[6].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.strComment), @"\0", string.Empty);
                this.dataGridView1.Rows[index1].Cells[4].Value = msg.nSignalCount;
                for (int i = 0; i < msg.nSignalCount; i++)
                {
                    int index2 = dataGridView2.Rows.Add();
                    this.dataGridView2.Rows[index2].Cells[14].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.vSignals[i].strComment), @"\0", string.Empty);
                    this.dataGridView2.Rows[index2].Cells[13].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.vSignals[i].unit), @"\0", string.Empty);
                    this.dataGridView2.Rows[index2].Cells[12].Value = msg.vSignals[i].nValue;
                    this.dataGridView2.Rows[index2].Cells[11].Value = msg.vSignals[i].nRawValue;
                    this.dataGridView2.Rows[index2].Cells[10].Value = msg.vSignals[i].nMax;
                    this.dataGridView2.Rows[index2].Cells[9].Value = msg.vSignals[i].nMin;
                    this.dataGridView2.Rows[index2].Cells[8].Value = msg.vSignals[i].nOffset;
                    this.dataGridView2.Rows[index2].Cells[7].Value = msg.vSignals[i].nFactor;
                    this.dataGridView2.Rows[index2].Cells[6].Value = msg.vSignals[i].nLen;
                    this.dataGridView2.Rows[index2].Cells[5].Value = msg.vSignals[i].nStartBit;
                    this.dataGridView2.Rows[index2].Cells[4].Value = msg.vSignals[i].is_signed;
                    this.dataGridView2.Rows[index2].Cells[3].Value = msg.vSignals[i].is_motorola;
                    this.dataGridView2.Rows[index2].Cells[2].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.vSignals[i].strName), @"\0", string.Empty);
                    this.dataGridView2.Rows[index2].Cells[1].Value = msg.nID;
                }


                Marshal.DestroyStructure(pt, typeof(DBCMessage));//释放内存
                pt = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DBCMessage)));

                while (DBCjiexi.DBC_GetNextMessage(HDBC, pt))
                {

                    msg = (DBCMessage)Marshal.PtrToStructure(pt, typeof(DBCMessage));
                    m_vMsg.Add(msg);

                    index1 = dataGridView1.Rows.Add();

                    this.dataGridView1.Rows[index1].Cells[0].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.strName), @"\0", string.Empty);
                    this.dataGridView1.Rows[index1].Cells[1].Value = msg.nID;
                    if (msg.nExtend == 0)
                    {
                        this.dataGridView1.Rows[index1].Cells[3].Value = "标准帧";
                    }
                    else
                    {
                        this.dataGridView1.Rows[index1].Cells[3].Value = "扩展帧";
                    }
                    this.dataGridView1.Rows[index1].Cells[6].Value = Regex.Replace(System.Text.Encoding.Default.GetString(msg.strComment), @"\0", string.Empty);
                    this.dataGridView1.Rows[index1].Cells[4].Value = msg.nSignalCount;
                    Marshal.DestroyStructure(pt, typeof(DBCMessage));//释放内存
                    pt = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DBCMessage)));
                }

            }

        }

        private void Button_saveJX_Click(object sender, EventArgs e)
        {
            string localFilePath = Application.StartupPath.Trim() + "解析数据" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + ".txt";
            Savetxt(localFilePath);
        }

        public void Savetxt(string Path)
        {
            if (Path == "")
            {
                return;
            }
            StreamWriter swStream;
            if (File.Exists(Path))
            {
                swStream = new StreamWriter(Path);
            }
            else
            {
                swStream = File.CreateText(Path);
            }
            string str = "";
            try
            {
                //标题
                for (int i = 0; i < dataGridView2.ColumnCount; i++)
                {
                    if (i > 0)
                    {
                        str += "\t";
                    }
                    str += dataGridView2.Columns[i].HeaderText.Trim();
                }
                swStream.WriteLine(str);
                //插入分隔符
                swStream.Write("  ");
                //内容
                for (int j = 0; j < dataGridView2.Rows.Count; j++)
                {
                    string tempStr = "";
                    for (int k = 0; k < dataGridView2.Columns.Count; k++)
                    {
                        if (k > 0)
                        {
                            tempStr += "\t";
                        }
                        tempStr += dataGridView2.Rows[j].Cells[k].Value;
                       //以免打开时转数字
                    }
                    swStream.WriteLine(tempStr);
                    //插入分隔符
                    swStream.Write("  ");
                }
                swStream.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                swStream.Close();
            }
        }

        private void Button_JXopen_Click(object sender, EventArgs e)
        {
            if (SSflag)
            {
                button_JXopen.Enabled = false;
                timerSS.Start();
            }
            else
            {
                MethodJ1939();
            }
        }

        private void MethodJ1939()
        {
            for (int i = 0; i < m_vMsg.Count; i++)
            {
                if (SSflag&&JXOKflag)
                {
                    timerSS.Stop();
                    MessageBox.Show("解析完毕", "提示");
                    JXingflag = false;
                    return;
                }
                else
                {
                    if (m_vMsg[i].nID == Convert.ToUInt32(SCADA.ZID))
                    {
                        //十六进制字符串转为二进制字符串 
                        string dataA = HexString2BinString(SCADA.Zdata.Replace(" ", ""));//替换掉空格防止出错
                        for (int j = 0; j < m_vMsg[i].nSignalCount; j++)
                        {
                            int dgv2index = dataGridView2.Rows.Add();
                            this.dataGridView2.Rows[dgv2index].Cells[14].Value = Regex.Replace(System.Text.Encoding.Default.GetString(m_vMsg[i].vSignals[j].strComment), @"\0", string.Empty);
                            this.dataGridView2.Rows[dgv2index].Cells[13].Value = Regex.Replace(System.Text.Encoding.Default.GetString(m_vMsg[i].vSignals[j].unit), @"\0", string.Empty);
                            this.dataGridView2.Rows[dgv2index].Cells[11].Value = m_vMsg[i].vSignals[j].nRawValue;
                            this.dataGridView2.Rows[dgv2index].Cells[10].Value = m_vMsg[i].vSignals[j].nMax;
                            this.dataGridView2.Rows[dgv2index].Cells[9].Value = m_vMsg[i].vSignals[j].nMin;
                            this.dataGridView2.Rows[dgv2index].Cells[8].Value = m_vMsg[i].vSignals[j].nOffset;
                            this.dataGridView2.Rows[dgv2index].Cells[7].Value = m_vMsg[i].vSignals[j].nFactor;
                            this.dataGridView2.Rows[dgv2index].Cells[6].Value = m_vMsg[i].vSignals[j].nLen;
                            this.dataGridView2.Rows[dgv2index].Cells[5].Value = m_vMsg[i].vSignals[j].nStartBit;
                            this.dataGridView2.Rows[dgv2index].Cells[4].Value = m_vMsg[i].vSignals[j].is_signed;
                            this.dataGridView2.Rows[dgv2index].Cells[3].Value = m_vMsg[i].vSignals[j].is_motorola;
                            dataGridView2.Rows[dgv2index].Cells[2].Value = Regex.Replace(Encoding.Default.GetString(m_vMsg[i].vSignals[j].strName), @"\0", string.Empty);
                            this.dataGridView2.Rows[dgv2index].Cells[1].Value = m_vMsg[i].nID;
                            dataGridView2.Rows[dgv2index].Cells[0].Value = SCADA.JieShouXuHao;
                            //sub方法是从左往右提取，故起始位是 ZDLC*8-nStart-nLen
                            string str = dataA.Substring((Convert.ToInt32(SCADA.ZDLC) * 8) - (int)m_vMsg[i].vSignals[j].nStartBit - (int)m_vMsg[i].vSignals[j].nLen, (int)m_vMsg[i].vSignals[j].nLen);
                            //转为10进制开始计算
                            double RealValue = (Convert.ToUInt32(str, 2) * m_vMsg[i].vSignals[j].nFactor) + m_vMsg[i].vSignals[j].nOffset;
                            dataGridView2.Rows[dgv2index].Cells[12].Value = RealValue;
                            //画图用
                            XuHao.Add(SCADA.JieShouXuHao);
                            datavalue1.Add(RealValue);
                        }
                    }
                }
            }
            JXingflag = false;
            JXOKflag = DATASendOKflag == true ? true : false;
    }

        static string HexString2BinString(string hexString)//十六进制字符串转二进制字符串
        {
            string result = "";//不能加空格，字符串长度不能变化，防止解析按位提取时出错
            foreach (char c in hexString)
            {
                int v = Convert.ToInt32(c.ToString(), 16);//把字符串的字节换成十进制数int
                int v2 = int.Parse(Convert.ToString(v, 2));//十进制数转化为二进制数
                result += string.Format("{0:d4}", v2);//把数字转换为二进制字符串
            }
            return result;
        }
   
        private void Button_JXstop_Click(object sender, EventArgs e)
        {
            timerSS.Stop();
            button_JXopen.Enabled = true;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (SSflag)
            {
                return;
            }
            int RowIndex = dataGridView1.CurrentCell.RowIndex;
            if (RowIndex > -1)
            {
                dataGridView2.Rows.Clear();
                for (int i = 0; i < m_vMsg.Count; i++)
                {
                    if (m_vMsg[i].nID == Convert.ToUInt32(dataGridView1.Rows[RowIndex].Cells["ID"].Value))
                    {
                        for (int j = 0; j < m_vMsg[i].nSignalCount; j++)
                        {
                            int dgv2index = dataGridView2.Rows.Add();
                            this.dataGridView2.Rows[dgv2index].Cells[14].Value = Regex.Replace(System.Text.Encoding.Default.GetString(m_vMsg[i].vSignals[j].strComment), @"\0", string.Empty);
                            this.dataGridView2.Rows[dgv2index].Cells[13].Value = Regex.Replace(System.Text.Encoding.Default.GetString(m_vMsg[i].vSignals[j].unit), @"\0", string.Empty);
                            this.dataGridView2.Rows[dgv2index].Cells[12].Value = m_vMsg[i].vSignals[j].nValue;
                            this.dataGridView2.Rows[dgv2index].Cells[11].Value = m_vMsg[i].vSignals[j].nRawValue;
                            this.dataGridView2.Rows[dgv2index].Cells[10].Value = m_vMsg[i].vSignals[j].nMax;
                            this.dataGridView2.Rows[dgv2index].Cells[9].Value = m_vMsg[i].vSignals[j].nMin;
                            this.dataGridView2.Rows[dgv2index].Cells[8].Value = m_vMsg[i].vSignals[j].nOffset;
                            this.dataGridView2.Rows[dgv2index].Cells[7].Value = m_vMsg[i].vSignals[j].nFactor;
                            this.dataGridView2.Rows[dgv2index].Cells[6].Value = m_vMsg[i].vSignals[j].nLen;
                            this.dataGridView2.Rows[dgv2index].Cells[5].Value = m_vMsg[i].vSignals[j].nStartBit;
                            this.dataGridView2.Rows[dgv2index].Cells[4].Value = m_vMsg[i].vSignals[j].is_signed;
                            this.dataGridView2.Rows[dgv2index].Cells[3].Value = m_vMsg[i].vSignals[j].is_motorola;
                            this.dataGridView2.Rows[dgv2index].Cells[2].Value = Regex.Replace(System.Text.Encoding.Default.GetString(m_vMsg[i].vSignals[j].strName), @"\0", string.Empty);
                            this.dataGridView2.Rows[dgv2index].Cells[1].Value = m_vMsg[i].nID;
                        }
                    }
                }
            }
        }

        private void Button_fanhui_Click(object sender, EventArgs e)
        {
            DBCjiexi.DBC_Release(HDBC);
            Close();
        }

        private void 解析_FormClosed(object sender, FormClosedEventArgs e)
        {
            DBCjiexi.DBC_Release(HDBC);
        }

        private void 解析_FormClosing(object sender, FormClosingEventArgs e)
        {
            DBCjiexi.DBC_Release(HDBC);
        }

        private void ComboBox_SS_SelectedIndexChanged(object sender, EventArgs e)
        {
            SSflag = comboBox_SS.SelectedIndex == 1 ? true : false;
        }

        private void TimerSS_Tick(object sender, EventArgs e)
        {
                MethodJ1939();
        }

        private void Button_Reset_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("该按钮将删除本界面所有数据！", "警告！", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                timerSS.Stop();
                m_vMsg.Clear();
                label_xieyi.Text = "协议类型";
                comboBox_SS.SelectedIndex = 0;
                button_JXopen.Enabled = true;
                dataGridView1.Rows.Clear();
                dataGridView2.Rows.Clear();
            }
        }

        private void Button_JXT_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (dataGridView1.Rows[i].Cells[1].Value.ToString()== "150892286")//判断信号数量，本次试验为4条
                {
                    num = dataGridView1.Rows[i].Cells[4].Value.ToString();
                    break;
                }
            }
            画图 f1 = new 画图();
            f1.Show();
        }
    }
}
