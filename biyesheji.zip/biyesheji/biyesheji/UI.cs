﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using GCKJ;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using Microsoft.Office.Interop.Excel;
using ExcelApplication = Microsoft.Office.Interop.Excel.Application;
using System.Reflection;
using System.Text;
using System.Collections.Generic;

namespace biyesheji
{
    public partial class SCADA : Form//从Form类派生的自己写的类
    {
        public int xuhao = 2;            //判断当前是否接受数据的标志
        public static int JieShouXuHao_ = 0;      //接收序号
        public static string JieShouXuHao= "0";   //当前序号
        public static uint m_devind;           //设备索引号
        public static uint m_canind;     //通道号
        public static uint channelMAX = 2; //设备的最大通道数，可自定义最好和硬件一致
        public static uint m_devtype;//本次实验的设备类型为USBCAN2
        public static string ZID = "0";//将选中行的帧ID传递给解析窗体
        public static string Zdata = "0";//帧数据
        public static string ZDLC ;//帧长度
        public static string ZTime;//接收时间
        private int CAN1n = 0;//通道接收帧数
        private int CAN2n = 0;
        //奇偶报文注意错位写
        static string[] ZFSdata =new string[]{
            "0000000000000000",
            "0001000100010001",
            "0200020002000200",
            "0006000600060006",
            "0800080008000800",
            "000A000A000A000A",
            "0C000C000C000C00",
            "000F000F000F000F",
            "1100110011001100",
            "0014001400140014",
            "1700170017001700",
            "001C001C001C001C",
            "1E001E001E001E00",
            "0022002200220022",
            "1E001E001E001E00",
            "001A0019001C001B",
            "180017001A001900",
            "0016001600160016",
            "1100110011001100",
            "000C000C000C000C",
            "0800080008000800",
            "0002000200020002",
            "0000000000000000",
            "0000000000000000"
        };
        List<string> list = new List<string>(ZFSdata);
        private int numbe = 0;//应该发送上文中的那一个字节
        private int numbe2 =0;
        int flag = 0;//测试用标记

        byte m_connect = 0;//设备连接状态

        ComProc mCan = new ComProc();


        private void IncludeTextMessage(string strMsg)
        {
            lbxInfo.Items.Add(strMsg);
            lbxInfo.SelectedIndex = lbxInfo.Items.Count - 1;
        }

        public SCADA()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //初始化控件和下拉框值
            button_init.Enabled = false;
            ComboBox_BC.SelectedIndex = 1;//默认手动保存
            ComboBox_BCLX.SelectedIndex = 0;//默认保存文本文件
            comboBox_device.SelectedIndex = 0;
            comboBox_mode.SelectedIndex = 0;
            comboBox_baud.SelectedIndex = 0;
            textBox_startid.Text = "00000000";
            textBox_endid.Text = "FFFFFFFF";
            comboBox_netmode.SelectedIndex = 0;
            textBox_localport.Text = "1080";
            textBox_remoteaddr.Text = "192.168.28.222";
            textBox_remoteport.Text = "4001";
            setComboboxIndex(0, 32, 0);
        }


        private void SCADA_FormClosed(object sender, FormClosedEventArgs e)//防止意外关闭导致下次使用异常
        {
            this.m_connect = 0;
            this.mCan.EnableProc = false;
        }

        //初始化
        private void Button_init_Click(object sender, EventArgs e)
        {
            button_init.Enabled = false;//一次仅能初始化一次
            CAN1n = 0;
            CAN2n = 0;
            INIT_CONFIG init_config = new INIT_CONFIG();
            //滤波要根据cantest软件计算，此处不滤波
            init_config.AccCode = 0;
            init_config.AccMask = 0xffffff;
            init_config.Filter = 0;
            init_config.Mode = (byte)comboBox_mode.SelectedIndex;
            switch (comboBox_baud.SelectedIndex)//根据下拉框的值配置波特率，单位Kbps
            {
                case 0: //1000

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x14;
                    break;
                case 1: //800

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x16;
                    break;
                case 2: //666

                    init_config.Timing0 = 0x80;
                    init_config.Timing1 = 0xb6;
                    break;
                case 3: //500

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x1c;
                    break;
                case 4://400

                    init_config.Timing0 = 0x80;
                    init_config.Timing1 = 0xfa;
                    break;
                case 5://250

                    init_config.Timing0 = 0x01;
                    init_config.Timing1 = 0x1c;
                    break;
                case 6://200

                    init_config.Timing0 = 0x81;
                    init_config.Timing1 = 0xfa;
                    break;
                case 7://125

                    init_config.Timing0 = 0x03;
                    init_config.Timing1 = 0x1c;
                    break;
                case 8://100

                    init_config.Timing0 = 0x04;
                    init_config.Timing1 = 0x1c;
                    break;
                case 9://80

                    init_config.Timing0 = 0x83;
                    init_config.Timing1 = 0xff;
                    break;
                case 10://50

                    init_config.Timing0 = 0x09;
                    init_config.Timing1 = 0x1c;
                    break;
            }
            for (uint i = 0; i < channelMAX; i++)
            {
                if (ECANDLL.InitCAN(m_devtype, m_devind, i, ref init_config) != ECANStatus.STATUS_OK)
                {

                    MessageBox.Show("初始化CAN"+i.ToString()+"失败!", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ECANDLL.CloseDevice(m_devtype, m_devind);
                    return;
                }
            }
            for (uint i = 0; i < channelMAX; i++)
            {
                if (ECANDLL.StartCAN(m_devtype, m_devind, i) == ECANStatus.STATUS_OK)
                {
                    IncludeTextMessage("打开CAN"+(i+1).ToString()+"成功");

                }
                else
                {
                    IncludeTextMessage("打开CAN" + (i+1).ToString() + "失败");
                }
            }
        }

        //开始录入
        private void Button_start_Click(object sender, EventArgs e)
        {
            if (m_connect != 0)
            {
                if (button_start.Text == "启动录入")
                {
                    mCan.EnableProc = true;
                    timer_status.Start();
                    tmrRead.Start();
                    button_start.Text = "关闭录入";
                }
                else
                {
                    if (button_start.Text == "关闭录入")
                    {
                        mCan.EnableProc = false;//关闭录入
                        timerSend.Stop();//测试都结束
                        timer_status.Stop();
                        timerFZ.Stop();
                        labelDATA.BackColor =  Color.Red;
                        labelDATA.Text ="数据未接收";
                        tmrRead.Stop();
                        button_start.Text = "启动录入";
                    }
                }
            }
            else
            {
                MessageBox.Show("还未打开设备!", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private void Button_clear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("是否清空录入区？", "警告！", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                listView1.Items.Clear();
                JieShouXuHao_ = 0;      //接收序号
                JieShouXuHao = "0";   //当前序号
            }
        }
        private void ComboBox_device_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            comboBox_channel.Items.Clear();
            EnableSet();
        }
        private void ComboBox_channel_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            m_canind = (uint)comboBox_channel.SelectedIndex;
        }

        private void setComboboxIndex(int start, int end, int current)
        {
            for (int i = start; i < end; ++i)
            {
                comboBox_index.Items.Add(i);
            }

            comboBox_index.SelectedIndex = current;
        }


        //listView接收

        private void EnableSet()
        {
            bool netDevice = comboBox_device.Items.ToString() == "USBTCP" ? true : false;
            comboBox_mode.Enabled = !netDevice;
            comboBox_baud.Enabled = !netDevice;
            textBox_startid.Enabled = !netDevice;
            textBox_endid.Enabled = !netDevice;
            comboBox_index.Enabled = !netDevice;
            label_baud.Enabled = !netDevice;
            label_startid.Enabled = !netDevice;
            label_endid.Enabled = !netDevice;
            label_index.Enabled = !netDevice;
            comboBox_netmode.Enabled = netDevice;
            textBox_localport.Enabled = netDevice;
            textBox_remoteaddr.Enabled = netDevice;
            textBox_remoteport.Enabled = netDevice;
            label_netmode.Enabled = netDevice;
            label_localport.Enabled = netDevice;
            label_remoteaddr.Enabled = netDevice;
            label_remoteport.Enabled = netDevice;
        }
        private void ComboBox_netmode_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnableSet();
        }

        private void ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }


        private void SJFX_Click(object sender, EventArgs e)
        {
            解析 DBCform = new 解析();
            DBCform.Show();
        }

        private void SaveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Button_BC_Click(object sender, EventArgs e)
        {
            //默认在工程下Bin的程序集Debug目录下
            if (ComboBox_BCLX.SelectedIndex == 0)//文本文件
            {
                for (int i = 1; i <= channelMAX; i++)//同一个通道保存在一起
                {
                    string localFilePath = System.Windows.Forms.Application.StartupPath.Trim() + "CAN"+i.ToString()+"录入" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + ".txt";
                    Savetxt(localFilePath,i);
                }
            }
            else
            {
                string localFilePath = System.Windows.Forms.Application.StartupPath.Trim() + "录入数据" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss")+".xls";
                SaveExcel(listView1,localFilePath);
            }
       
        }

        public void SaveExcel(ListView pListView, string localFilePath)
        {
            string saveFileName = localFilePath;
            //文件存在则直接删除
            if (File.Exists(saveFileName)) File.Delete(saveFileName);
            ExcelApplication xlApp = new ExcelApplication();
            if (xlApp == null)
            {
                MessageBox.Show("无法创建Excel对象，可能您的机器未安装Excel");
                return;
            }
            Workbooks workbooks = xlApp.Workbooks;
            Workbook workbook = workbooks.Add(true);
            Worksheet worksheet = (Worksheet)workbook.Worksheets[1];
            xlApp.Visible = false;
            //填充列
            for (int i = 0; i < pListView.Columns.Count; i++)
            {
                worksheet.Cells[1, i + 1] = pListView.Columns[i].Text.ToString();
                ((Range)worksheet.Cells[1, i + 1]).Font.Bold = true;
            }
            //填充数据（这里分了两种情况，1：lv带CheckedBox，2：不带CheckedBox）
            //带CheckedBoxes
            if (pListView.CheckBoxes == true)
            {
                int tmpCnt = 0;
                for (int i = 0; i < pListView.Items.Count; i++)
                {
                    if (pListView.Items[i].Checked == true)
                    {
                        for (int j = 0; j < pListView.Columns.Count; j++)
                        {
                            if (j == 0)
                            {
                                worksheet.Cells[2 + tmpCnt, j + 1] = pListView.Items[i].Text.ToString();
                                ((Range)worksheet.Cells[2 + tmpCnt, j + 1]).HorizontalAlignment = XlHAlign.xlHAlignLeft;
                            }
                            else
                            {
                                worksheet.Cells[2 + tmpCnt, j + 1] = pListView.Items[i].SubItems[j].Text.ToString();
                                ((Range)worksheet.Cells[2 + tmpCnt, j + 1]).HorizontalAlignment = XlHAlign.xlHAlignLeft;
                            }
                        }
                        tmpCnt++;
                    }
                }
            }
            else //不带Checkedboxe
            {
                for (int i = 0; i < pListView.Items.Count; i++)
                {
                    for (int j = 0; j < pListView.Columns.Count; j++)
                    {
                        if (j == 0)
                        {
                            worksheet.Cells[2 + i, j + 1] = pListView.Items[i].Text.ToString();
                            ((Range)worksheet.Cells[2 + i, j + 1]).HorizontalAlignment = XlHAlign.xlHAlignLeft;
                        }
                        else
                        {
                            worksheet.Cells[2 + i, j + 1] = pListView.Items[i].SubItems[j].Text.ToString();
                            ((Range)worksheet.Cells[2 + i, j + 1]).HorizontalAlignment = XlHAlign.xlHAlignLeft;
                        }
                    }
                }
            }
            object missing = Missing.Value;
            try
            {
                workbook.Saved = true;
                workbook.SaveAs(saveFileName, XlFileFormat.xlXMLSpreadsheet, missing, missing, false, false, XlSaveAsAccessMode.xlNoChange, missing, missing, missing, missing, missing);
            }
            catch (Exception e1)
            {
                MessageBox.Show("导出文件时出错,文件可能正被打开！\n" + e1.Message);
            }
            finally
            {
                xlApp.Quit();
                System.GC.Collect();
            }
        }


        private void Savetxt(string localFilePath,int g)//区分保存那一个区域的数据
        {
            //写入txt文件
            try
            {
                StreamWriter swStream;
                    swStream = new StreamWriter(localFilePath,false);//文件名相同覆盖写法
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    if (listView1.Items[i].SubItems[7].Text == ("CAN"+g.ToString()))//同一个通道的文件放在一起
                    {
                        for (int j = 0; j < listView1.Items[i].SubItems.Count; j++)
                        {
                            string _strTemp = listView1.Items[i].SubItems[j].Text;
                            swStream.Write(_strTemp);
                            //插入分隔符
                            swStream.Write("  ");
                        }
                        swStream.Write("\r\n");//每条报文之间换行
                        swStream.WriteLine();
                    }
                }
                swStream.Flush();
                swStream.Close();
                if (ComboBox_BC.Text != "自动保存"&&(g==channelMAX))
                {
                    MessageBox.Show("保存成功");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("保存失败");
            }
        }

        private void Button_LCW_Click(object sender, EventArgs e)
        {
            sfd.FileName = "CAN1录入" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
            sfd.FilterIndex = 0;
            if (ComboBox_BCLX.SelectedIndex != 0)//文本文件
            {
                sfd.FilterIndex = 2;
            }
            //保存按钮框弹出后
            if (sfd.ShowDialog() == DialogResult.OK && sfd.FileName.Length > 0)
            {
                if (ComboBox_BCLX.SelectedIndex == 0)//文本文件
                {
                    for (int i = 1; i <= channelMAX; i++)
                    {   
                        Savetxt(sfd.FileName, i);
                    }
                }
                else
                {
                    SaveExcel(listView1,sfd.FileName);
                }
            }
        }



        private void Button_Test_Click_1(object sender, EventArgs e)
        {
            if (this.m_connect == 0)
            {
                MessageBox.Show("还未打开设备!", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                if (button_start.Text == "关闭录入")
                {
                    SendMethod();
                    timerSend.Start();
                }
                else
                {
                    MessageBox.Show("接收未启动!", "错误!");
                }
            }
        }

        private void Button_Help_Click(object sender, EventArgs e)
        {
            string filePath = System.Windows.Forms.Application.StartupPath.Trim() + "//Help.txt";
            _ = Process.Start(filePath);
        }

        private void SCADA_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.m_connect = 0;
            this.mCan.EnableProc = false;
        }

        private void Button_open_Click_1(object sender, EventArgs e)
        {
            m_devtype = (uint)comboBox_device.SelectedIndex;
            m_devind = (uint)comboBox_index.SelectedIndex;
            m_canind = (uint)comboBox_channel.SelectedIndex;
            if (m_connect == 1)//已经连接了则关闭
            {
                m_connect = 0;
                ECANDLL.CloseDevice(m_devtype, m_devind);
                button_open.Text = "打开设备";
                button_init.Enabled = false;
                label2.BackColor = Color.Red;
                label2.Text = "设备未连接";
                timer_status.Stop();
                return;
            }
            for (uint i = 0; i < channelMAX; i++)
            {
                if (ECANDLL.OpenDevice(1, 0, i) != ECANStatus.STATUS_OK )
                {
                    _ = MessageBox.Show("打开设备失败,请检查设备类型和设备索引号是否正确", "错误", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            m_connect = 1;
            button_init.Enabled = true;
            label2.BackColor = Color.Green;
            label2.Text = "设备已连接";
            button_open.Text = "关闭设备";
            IncludeTextMessage("打开成功");
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            if (m_connect == 0)
            {
                MessageBox.Show("还未打开设备!", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }
            if (ECANDLL.ResetCAN(m_devtype, m_devind, 0) == ECANStatus.STATUS_OK)
            {
                button_start.Text = "启动录入";
                mCan.EnableProc = false;//关闭录入
                tmrRead.Stop();
                tmrRead.Enabled = false;
                IncludeTextMessage("复位成功");
            }
            else
            {
                IncludeTextMessage("复位失败");
            }

        }

        private void TmrRead_Tick(object sender, EventArgs e)
        {
            xuhao = JieShouXuHao_;
            ReadMessages1();
            ReadMessages2();
            ReadError1();
            if (ComboBox_BC.Text == "自动保存"&& (xuhao < listView1.Items.Count))
            {       
                for (int i = 1; i <= channelMAX; i++)
                {
                    string localFilePath = System.Windows.Forms.Application.StartupPath.Trim() + "CAN"+i.ToString()+"录入" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm") + ".txt";
                    Savetxt(localFilePath, i);
                }
            }
            if (!解析.JXingflag)//解析完一条再跳到下一条
            {
                if (解析.SSflag)//自动选择最新的行
                {
                    int index = listView1.SelectedItems[0].Index + 1;
                    if (index == listView1.Items.Count - 1)
                    {
                        解析.DATASendOKflag = true;
                    }
                    if (listView1.Items.Count > index )
                    {
                        listView1.Items[index].Selected = true;//选中下一行
                        listView1.Items[index - 1].Selected = false;
                    }
                    解析.JXingflag = true;
                }
            }
        }
        private void ReadMessages2()//读二通道的信息
        {
            _ = new CAN_OBJ();
            int mCount = 0;
            ListViewItem listViewItem = new ListViewItem();

            while (this.mCan.gRecMsgBufHead2 != this.mCan.gRecMsgBufTail2)
            {
                CAN_OBJ frameinfo2 = this.mCan.gRecMsgBuf2[this.mCan.gRecMsgBufTail2];
                this.mCan.gRecMsgBufTail2 += 1;
                if (this.mCan.gRecMsgBufTail2 >= ComProc.REC_MSG_BUF_MAX)
                {
                    this.mCan.gRecMsgBufTail2 = 0;
                }
                listViewItem.Text = JieShouXuHao_.ToString();
                JieShouXuHao_++;

                if (frameinfo2.TimeFlag == 0)
                {
                    listViewItem.SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff"));
                }
                else
                {
                    listViewItem.SubItems.Add(string.Format("{0:X8}h", frameinfo2.TimeStamp));
                }

                listViewItem.SubItems.Add("接收");

                if (frameinfo2.RemoteFlag == 0)
                {
                    listViewItem.SubItems.Add("数据帧");
                }
                else
                {
                    listViewItem.SubItems.Add("远程帧");
                }

                if (frameinfo2.ExternFlag == 0)
                {
                    listViewItem.SubItems.Add("标准帧");
                }
                else
                {
                    listViewItem.SubItems.Add("扩展帧");
                }

                listViewItem.SubItems.Add(frameinfo2.DataLen.ToString("D1"));
                listViewItem.SubItems.Add(frameinfo2.ID.ToString());
                listViewItem.SubItems.Add("CAN2");//第二个通道

                if (frameinfo2.RemoteFlag == 0)
                {
                    string str = "";
                    if (frameinfo2.DataLen > 8)
                    {
                        frameinfo2.DataLen = 8;
                    }
                    int mlen = frameinfo2.DataLen - 1;
                    for (int j = 0; j <= mlen; j++)
                    {
                        string tmpstr = string.Format("{0:X2} ", frameinfo2.data[j]);
                        str += tmpstr;
                    }
                    listViewItem.SubItems.Add(str);
                }
                listView1.Items.Add(listViewItem);
                CAN2n++;
                if (listView1.Items.Count > 500)
                {
                    listView1.Items.Clear();
                }
                mCount++;
                if (mCount >= 50)
                {
                    break;
                }
                System.Windows.Forms.Application.DoEvents();
            }
        }
        private void ReadMessages1()//读一通道的信息 读二通道同理
        {
            _ = new CAN_OBJ();
            int mCount = 0;
            ListViewItem listViewItem = new ListViewItem();
   
            while (this.mCan.gRecMsgBufHead != this.mCan.gRecMsgBufTail)
            {
                CAN_OBJ frameinfo1 = this.mCan.gRecMsgBuf[this.mCan.gRecMsgBufTail];
                this.mCan.gRecMsgBufTail += 1;
                if (this.mCan.gRecMsgBufTail >= ComProc.REC_MSG_BUF_MAX)
                {
                    this.mCan.gRecMsgBufTail = 0;
                }
                listViewItem.Text = JieShouXuHao_.ToString();
                JieShouXuHao_++;
              
                if (frameinfo1.TimeFlag == 0)
                {
                    listViewItem.SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff"));
                }
                else
                {
                    listViewItem.SubItems.Add(string.Format("{0:X8}h", frameinfo1.TimeStamp));
                }

                listViewItem.SubItems.Add("接收");

                if (frameinfo1.RemoteFlag == 0)
                {
                    listViewItem.SubItems.Add("数据帧");
                }
                else
                {
                    listViewItem.SubItems.Add("远程帧");
                }

                if (frameinfo1.ExternFlag == 0)
                {
                    listViewItem.SubItems.Add("标准帧");
                }
                else
                {
                    listViewItem.SubItems.Add("扩展帧");
                }

                listViewItem.SubItems.Add(frameinfo1.DataLen.ToString("D1"));
                listViewItem.SubItems.Add(frameinfo1.ID.ToString());
                listViewItem.SubItems.Add("CAN1");//第一个通道

                if (frameinfo1.RemoteFlag == 0)
                {
                    string str = "";
                    if (frameinfo1.DataLen > 8)
                    {
                        frameinfo1.DataLen = 8;
                    }
                    int mlen = frameinfo1.DataLen - 1;
                    for (int j = 0; j <= mlen; j++)
                    {
                        string tmpstr = string.Format("{0:X2} ", frameinfo1.data[j]);
                        str += tmpstr;
                    }
                    listViewItem.SubItems.Add(str);
                }
                listView1.Items.Add(listViewItem);
                CAN1n++;
                if (listView1.Items.Count > 500)
                {
                    listView1.Items.Clear();
                }
                mCount++;
                if (mCount >= 50)
                {
                    break;
                }
                System.Windows.Forms.Application.DoEvents();
            }
        }
        private void ReadError1()
        {
            _ = new CAN_ERR_INFO();
            CAN_ERR_INFO mErrInfo;
            if (ECANDLL.ReadErrInfo(1, 0, 0, out mErrInfo) == ECANStatus.STATUS_OK)
            {
                labErrInfo1.Text = $"{mErrInfo.ErrCode:X4}h";
                labRx.Text = $"{mErrInfo.Passive_ErrData[1]:X4}h";
            }
            else
            {
                labErrInfo1.Text = "读错误信息失败";
            }
        }

   

        private void TimerSend_Tick(object sender, EventArgs e)
        {
            if (flag==0)
            {
                SendMethod();
            }
            else
            {
                SendMethod2();
            }
            flag = flag == 0 ? 1 : 0;
        }
        private void SendMethod2()
        {
            CAN_OBJ frameinfo = new CAN_OBJ();
            frameinfo.data = new byte[8];
            frameinfo.Reserved = new byte[2];
            frameinfo.ExternFlag = 1;//J1939大多都是扩展帧
            frameinfo.RemoteFlag = 0;//数据采集器接收控制中心的远程帧，自己不能发给别人
            frameinfo.ID = 16594942;
            frameinfo.DataLen = 5;
            frameinfo.data[4] = Convert.ToByte("20", 0x10);
            frameinfo.data[3] = Convert.ToByte("4E", 0x10);
            frameinfo.data[2] = Convert.ToByte("D0", 0x10);
            frameinfo.data[1] = Convert.ToByte("07", 0x10);
            frameinfo.data[0] = Convert.ToByte("96", 0x10);
            this.mCan.gSendMsgBuf[this.mCan.gSendMsgBufHead].ID = frameinfo.ID;
            this.mCan.gSendMsgBuf[this.mCan.gSendMsgBufHead].DataLen = frameinfo.DataLen;
            this.mCan.gSendMsgBuf[this.mCan.gSendMsgBufHead].data = frameinfo.data;
            this.mCan.gSendMsgBuf[this.mCan.gSendMsgBufHead].ExternFlag = frameinfo.ExternFlag;
            this.mCan.gSendMsgBuf[this.mCan.gSendMsgBufHead].RemoteFlag = frameinfo.RemoteFlag;
            this.mCan.gSendMsgBufHead += 1;
            if (this.mCan.gSendMsgBufHead >= ComProc.SEND_MSG_BUF_MAX)
            {
                this.mCan.gSendMsgBufHead = 0;
            }
        }

        private void SendMethod()
        {
            CAN_OBJ frameinfo = new CAN_OBJ();
            frameinfo.data = new byte[8];
            frameinfo.Reserved = new byte[2];
            frameinfo.ExternFlag = 1;//J1939大多都是扩展帧
            frameinfo.RemoteFlag = 0;//数据采集器接收控制中心的远程帧，自己不能发给别人
                frameinfo.ID = 217058046;
                frameinfo.DataLen = 6;
                int tlen = frameinfo.DataLen - 1;
                frameinfo.data[5] = Convert.ToByte("88", 0x10);
                frameinfo.data[4] = Convert.ToByte("0B", 0x10);
                frameinfo.data[3] = Convert.ToByte("A0", 0x10);
                frameinfo.data[2] = Convert.ToByte("0F", 0x10);
                frameinfo.data[1] = Convert.ToByte("D0", 0x10);
                frameinfo.data[0] = Convert.ToByte("07", 0x10);
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].ID = frameinfo.ID;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].DataLen = frameinfo.DataLen;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].data = frameinfo.data;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].ExternFlag = frameinfo.ExternFlag;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].RemoteFlag = frameinfo.RemoteFlag;
            this.mCan.gSendMsgBufHead2 += 1;
            if (this.mCan.gSendMsgBufHead2 >= ComProc.SEND_MSG_BUF_MAX)
            {
                this.mCan.gSendMsgBufHead2 = 0;
            }
        }

        private void Timer1_Tick_1(object sender, EventArgs e)
        {
            labelBuf.BackColor = labErrInfo1.Text == "0800h" ? Color.Red : Color.Green;
            labelBuf.Text = labErrInfo1.Text == "0800h" ? "缓存区已满" : "缓存区未满";
            labelDATA.BackColor = xuhao == listView1.Items.Count ? Color.Red: Color.Green;
            labelDATA.Text = xuhao == listView1.Items.Count? "数据未接收" : "数据接收中";
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;
            else
            {
                 ZID = listView1.SelectedItems[0].SubItems[6].Text;
                Zdata = listView1.SelectedItems[0].SubItems[8].Text;
                JieShouXuHao = listView1.SelectedItems[0].SubItems[0].Text;
                ZDLC = listView1.SelectedItems[0].SubItems[5].Text;
                ZTime = listView1.SelectedItems[0].SubItems[1].Text;
                // IncludeTextMessage(listView1.SelectedIndices[0].ToString());//检查向解析窗口传递的是否是帧ID
            }
        }

        private void Button_TestJX_Click(object sender, EventArgs e)
        {
            Random s = new Random();
            ListViewItem listViewItem = new ListViewItem();
            if (flag == 1)//催化剂
            {
                listViewItem.Text = s.Next(100).ToString();
                listViewItem.SubItems.Add("test");
                listViewItem.SubItems.Add("接收");
                listViewItem.SubItems.Add("数据帧");
                listViewItem.SubItems.Add("扩展帧");
                listViewItem.SubItems.Add("5");
                listViewItem.SubItems.Add("16594942");
                listViewItem.SubItems.Add("CAN99");
                listViewItem.SubItems.Add("96 07 D0 4E 20");
            }
            else//引擎气体
            {
                listViewItem.Text = s.Next(100).ToString();
                listViewItem.SubItems.Add("test");
                listViewItem.SubItems.Add("接收");
                listViewItem.SubItems.Add("数据帧");
                listViewItem.SubItems.Add("扩展帧");
                listViewItem.SubItems.Add("6");
                listViewItem.SubItems.Add("217058046");
                listViewItem.SubItems.Add("CAN99");
                listViewItem.SubItems.Add("07 D0 0F A0 0B B8");
            }
            listView1.Items.Add(listViewItem);
            flag = flag == 0 ? 1 : 0;
        }

        private void Button_FZ_Click(object sender, EventArgs e)
        {
            if (this.m_connect == 0)
            {
                MessageBox.Show("还未打开设备!", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                if (button_start.Text == "关闭录入")
                {
                    timerFZ.Start();
                }
            }
        }

        private void TimerFZ_Tick(object sender, EventArgs e)
        {

            CAN_OBJ frameinfo = new CAN_OBJ();
            frameinfo.data = new byte[8];
            frameinfo.Reserved = new byte[2];
            frameinfo.ExternFlag = 1;//J1939大多都是扩展帧
            frameinfo.RemoteFlag = 0;//数据采集器接收控制中心的远程帧，自己不能发给别人
                frameinfo.ID = 150892286;
                frameinfo.DataLen = 8;
                int tlen = frameinfo.DataLen - 1;
            for (int i = 0; i < tlen; i++)
            {
                frameinfo.data[i] = Convert.ToByte(ZFSdata[numbe2].Substring(numbe * 2, 2), 0x10);
                numbe = numbe == 7 ? 0 : numbe + 1;
            }
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].ID = frameinfo.ID;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].DataLen = frameinfo.DataLen;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].data = frameinfo.data;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].ExternFlag = frameinfo.ExternFlag;
            this.mCan.gSendMsgBuf2[this.mCan.gSendMsgBufHead2].RemoteFlag = frameinfo.RemoteFlag;
            this.mCan.gSendMsgBufHead2 += 1;
            if (this.mCan.gSendMsgBufHead2 >= ComProc.SEND_MSG_BUF_MAX)
            {
                this.mCan.gSendMsgBufHead2 = 0;
            }
            numbe2 = numbe2 == ZFSdata.Length - 1 ? 0 : numbe2 + 1;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            timerSend.Stop();
            timerFZ.Stop();
        }

        private void Button_TJ_Click(object sender, EventArgs e)
        {
            IncludeTextMessage("CAN1录入" + CAN1n.ToString() + "帧");
            IncludeTextMessage("CAN2录入" + CAN2n.ToString() + "帧");
        }
    }
}