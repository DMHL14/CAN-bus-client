﻿using System;
using System.Runtime.InteropServices;

namespace GCKJ
{
    [Flags]
    public enum ECANStatus : uint
    {
        /// <summary>
        ///  error
        /// </summary>
        STATUS_ERR = 0x00000,
        /// <summary>
        /// No error
        /// </summary>
        STATUS_OK = 0x00001,


    }

    [StructLayout(LayoutKind.Sequential)]
    public struct CAN_OBJ
    {
        public uint ID;
        public uint TimeStamp;
        public byte TimeFlag;
        public byte SendType;
        public byte RemoteFlag;//远程
        public byte ExternFlag;//扩展
        public byte DataLen;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] data;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public byte[] Reserved;
    }

    public struct CAN_ERR_INFO
    {
        public uint ErrCode;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public byte[] Passive_ErrData;
        public byte ArLost_ErrData;

    }


    /*
 

    public struct CAN_OBJ
    {


        public uint ID;
      
        public uint TimeStamp;
        public byte TimeFlag;
        public byte RemoteFlag;
        public byte ExternFlag; 


        public byte DataLen;
 
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] data;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public byte[] Reserved;
    

    }
    */

    public struct INIT_CONFIG
    {

        public uint AccCode;
        public uint AccMask;
        public uint Reserved;
        public byte Filter;
        public byte Timing0;
        public byte Timing1;
        public byte Mode;



    }

    public struct BOARD_INFO
    {
        public ushort hw_Version;
        public ushort fw_Version;
        public ushort dr_Version;
        public ushort in_Version;
        public ushort irq_Num;
        public byte can_Num;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] str_Serial_Num;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
        public byte[] str_hw_Type;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public ushort[] Reserved;
    }

    public static class ECANDLL
    {

        [DllImport("ECANVCI.dll", EntryPoint = "OpenDevice")]
        public static extern ECANStatus OpenDevice(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 Reserved);

        [DllImport("ECANVCI.dll", EntryPoint = "CloseDevice")]
        public static extern ECANStatus CloseDevice(
            UInt32 DeviceType,
            UInt32 DeviceInd);


        [DllImport("ECANVCI.dll", EntryPoint = "InitCAN")]
        public static extern ECANStatus InitCAN(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 CANInd,
            ref INIT_CONFIG InitConfig);


        [DllImport("ECANVCI.dll", EntryPoint = "StartCAN")]
        public static extern ECANStatus StartCAN(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 CANInd);


        [DllImport("ECANVCI.dll", EntryPoint = "ResetCAN")]
        public static extern ECANStatus ResetCAN(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 CANInd);


        [DllImport("ECANVCI.dll", EntryPoint = "Transmit")]
        public static extern ECANStatus Transmit(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 CANInd,
            ref CAN_OBJ Send,
            UInt16 length);


        [DllImport("ECANVCI.dll", EntryPoint = "Receive")]
        public static extern ECANStatus Receive(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 CANInd,
            out CAN_OBJ Receive,
            UInt32 length,
            UInt32 WaitTime);

        [DllImport("ECANVCI.dll", EntryPoint = "ReadErrInfo")]
        public static extern ECANStatus ReadErrInfo(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            UInt32 CANInd,
            out CAN_ERR_INFO ReadErrInfo);



        [DllImport("ECANVCI.dll", EntryPoint = "ReadBoardInfo")]
        public static extern ECANStatus ReadBoardInfo(
            UInt32 DeviceType,
            UInt32 DeviceInd,
            out BOARD_INFO ReadErrInfo);

    }

    //DBC解析
    public struct DBCSignal
    {
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 66)]
        //public byte[] strName;//名称
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 201)]
        //public byte[] strComment;//注释
        //public uint nStartBit;//起始位
        //public uint nLen;//位长度
        //public double nFactor;//转换因子
        //public double nOffset;//转换偏移实际值=原始值*nFactor+nOffset
        //public double nMin;//最小值
        //public double nMax;//最大值
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        //public byte[] unit;//单位
        //public double nValue;//实际值

        public UInt32 nStartBit;//起始位
        public UInt32 nLen;//位长度
        public Double nFactor;//转换因子
        public Double nOffset;//转换偏移 实际值=原始值*nFactor+nOffset
        public Double nMin;    // 最小值
        public Double nMax;    // 最大值
        public Double nValue;  //实际值
        public UInt64 nRawValue;//原始值 
        public Byte is_signed; //1:有符号数据, 0:无符号
        public Byte is_motorola;//是否摩托罗拉格式
        public Byte multiplexer_type;//see 'multiplexer type' above
        public Byte multiplexer_value;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public Byte[] unit;


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        //[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        //public string strName;  //名称
        public Byte[] strName;

        //[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 201)]
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 201)]
        //public string strComment;  //注释
        public Byte[] strComment;


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        //[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        //public string strValDesc;  //值描述
        public Byte[] strValDesc;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct DBCMessage
    {
        public UInt32 nSignalCount; //信号数量
        public uint nID;
        public Byte nExtend; //1:扩展帧, 0:标准帧
        public UInt32 nSize;   //消息占的字节数目
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        public DBCSignal[] vSignals; //信号集合
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        //名称
        public byte[] strName;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 201)]
        //注释
        public byte[] strComment;
    }
    public enum ProtocolType
    {
        DBC_J1939,
        DBC_CAN,
    }
    public unsafe struct FileInfo
    {
        // [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1001)]
        public fixed byte strFilePath[1001];
        public ProtocolType nType;
        public SByte merge;//1:不清除现有的数据, 即支持加载多个文件
    }
    public struct DevInfo
    {
        public uint nDevType;
        public uint nDevIndex;
        public uint nChIndex;
    }

    public struct Ctx
    {
        public IntPtr powner;
        public DevInfo devinfo;
    }

    public static class DBCjiexi
    {

    [DllImport("LibDBCManager.dll")]
    static public extern int DBC_Init();
    [DllImport("LibDBCManager.dll")]
    static public extern void DBC_Release(Int32 hDBChandle);
    [DllImport("LibDBCManager.dll")]
    static public extern bool DBC_LoadFile(Int32 hDBC, ref GCKJ.FileInfo fileinfo);

    [DllImport("LibDBCManager.dll")]
    static public extern bool DBC_GetFirstMessage(Int32 hDBC, IntPtr pMsg);
    //static extern bool DBC_GetFirstMessage(Int32 hDBC, ref DBCMessage pMsg);
    [DllImport("LibDBCManager.dll")]
    //static extern bool DBC_GetNextMessage(Int32 hDBC, ref DBCMessage pMsg);
    static public extern bool DBC_GetNextMessage(Int32 hDBC, IntPtr pMsg);
    [DllImport("LibDBCManager.dll")]
    static public extern bool DBC_GetMessageById(Int32 hDBC, UInt32 nID, IntPtr pMsg);
    [DllImport("LibDBCManager.dll")]
    static public extern UInt32 DBC_GetMessageCount(Int32 hDBC);

    //此函数用以解析帧数据，返回解析结果.返回值为 true 表示解析成功， false 表示失败。
    [DllImport("LibDBCManager.dll")]
    static public extern bool DBC_Analyse(Int32 hDBC, IntPtr pOb, IntPtr pMsg);

    //用户需要调用该函数把接收到的帧数据传进来， 涉及多帧传输必须要调用， 否则无法实
    //现报文交互， 可以实现为接收到每一个帧都调用该函数一次。
    [DllImport("LibDBCManager.dll")]
    static public extern void DBC_OnReceive(Int32 hDBC, IntPtr pObj);

    [DllImport("LibDBCManager.dll")]
    static public extern bool DBC_Send(Int32 hDBC, IntPtr pMsg);

    }

}
