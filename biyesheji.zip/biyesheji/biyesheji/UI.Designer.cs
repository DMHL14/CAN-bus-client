﻿namespace biyesheji
{
    partial class SCADA
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCADA));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labRx = new System.Windows.Forms.Label();
            this.labErrInfo1 = new System.Windows.Forms.Label();
            this.labelDATA = new System.Windows.Forms.Label();
            this.labelBuf = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.label_device = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox_device = new System.Windows.Forms.ToolStripComboBox();
            this.label_index = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox_index = new System.Windows.Forms.ToolStripComboBox();
            this.label_channel = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox_channel = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ComboBox_BC = new System.Windows.Forms.ToolStripComboBox();
            this.ComboBox_BCLX = new System.Windows.Forms.ToolStripComboBox();
            this.button_BC = new System.Windows.Forms.ToolStripButton();
            this.button_LCW = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.SJFX = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.button_TJ = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.button_Help = new System.Windows.Forms.ToolStripButton();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.groupBox_param = new System.Windows.Forms.GroupBox();
            this.lbxInfo = new System.Windows.Forms.ListBox();
            this.label_baud = new System.Windows.Forms.Label();
            this.comboBox_baud = new System.Windows.Forms.ComboBox();
            this.textBox_remoteport = new System.Windows.Forms.TextBox();
            this.label_remoteport = new System.Windows.Forms.Label();
            this.textBox_remoteaddr = new System.Windows.Forms.TextBox();
            this.label_remoteaddr = new System.Windows.Forms.Label();
            this.button_reset = new System.Windows.Forms.Button();
            this.button_init = new System.Windows.Forms.Button();
            this.button_start = new System.Windows.Forms.Button();
            this.textBox_localport = new System.Windows.Forms.TextBox();
            this.label_localport = new System.Windows.Forms.Label();
            this.label_netmode = new System.Windows.Forms.Label();
            this.button_open = new System.Windows.Forms.Button();
            this.comboBox_netmode = new System.Windows.Forms.ComboBox();
            this.label_endid = new System.Windows.Forms.Label();
            this.textBox_endid = new System.Windows.Forms.TextBox();
            this.label_startid = new System.Windows.Forms.Label();
            this.textBox_startid = new System.Windows.Forms.TextBox();
            this.comboBox_mode = new System.Windows.Forms.ComboBox();
            this.label_mode = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.column_numLR = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_FX = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_GS = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_LX = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_DLC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_zID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_channel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_DATA = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button_Test = new System.Windows.Forms.Button();
            this.button_clear1 = new System.Windows.Forms.Button();
            this.tmrRead = new System.Windows.Forms.Timer(this.components);
            this.timerSend = new System.Windows.Forms.Timer(this.components);
            this.timer_status = new System.Windows.Forms.Timer(this.components);
            this.button_TestJX = new System.Windows.Forms.Button();
            this.button_FZ = new System.Windows.Forms.Button();
            this.timerFZ = new System.Windows.Forms.Timer(this.components);
            this.ofdFZ = new System.Windows.Forms.OpenFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox_param.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.labRx);
            this.panel2.Controls.Add(this.labErrInfo1);
            this.panel2.Controls.Add(this.labelDATA);
            this.panel2.Controls.Add(this.labelBuf);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // labRx
            // 
            resources.ApplyResources(this.labRx, "labRx");
            this.labRx.Name = "labRx";
            // 
            // labErrInfo1
            // 
            resources.ApplyResources(this.labErrInfo1, "labErrInfo1");
            this.labErrInfo1.Name = "labErrInfo1";
            // 
            // labelDATA
            // 
            resources.ApplyResources(this.labelDATA, "labelDATA");
            this.labelDATA.BackColor = System.Drawing.Color.Red;
            this.labelDATA.Name = "labelDATA";
            // 
            // labelBuf
            // 
            resources.ApplyResources(this.labelBuf, "labelBuf");
            this.labelBuf.BackColor = System.Drawing.Color.Chartreuse;
            this.labelBuf.Name = "labelBuf";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton3,
            this.toolStripSeparator1,
            this.ComboBox_BC,
            this.ComboBox_BCLX,
            this.button_BC,
            this.button_LCW,
            this.toolStripSeparator3,
            this.SJFX,
            this.toolStripSeparator4,
            this.button_TJ,
            this.toolStripSeparator2,
            this.button_Help});
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ToolStrip1_ItemClicked);
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.label_device,
            this.label_index,
            this.label_channel});
            resources.ApplyResources(this.toolStripDropDownButton3, "toolStripDropDownButton3");
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            // 
            // label_device
            // 
            this.label_device.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comboBox_device});
            this.label_device.Name = "label_device";
            resources.ApplyResources(this.label_device, "label_device");
            // 
            // comboBox_device
            // 
            this.comboBox_device.Items.AddRange(new object[] {
            resources.GetString("comboBox_device.Items"),
            resources.GetString("comboBox_device.Items1"),
            resources.GetString("comboBox_device.Items2")});
            this.comboBox_device.Name = "comboBox_device";
            resources.ApplyResources(this.comboBox_device, "comboBox_device");
            this.comboBox_device.SelectedIndexChanged += new System.EventHandler(this.ComboBox_device_SelectedIndexChanged_1);
            // 
            // label_index
            // 
            this.label_index.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comboBox_index});
            this.label_index.Name = "label_index";
            resources.ApplyResources(this.label_index, "label_index");
            // 
            // comboBox_index
            // 
            this.comboBox_index.Name = "comboBox_index";
            resources.ApplyResources(this.comboBox_index, "comboBox_index");
            // 
            // label_channel
            // 
            this.label_channel.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comboBox_channel});
            this.label_channel.Name = "label_channel";
            resources.ApplyResources(this.label_channel, "label_channel");
            // 
            // comboBox_channel
            // 
            this.comboBox_channel.Items.AddRange(new object[] {
            resources.GetString("comboBox_channel.Items"),
            resources.GetString("comboBox_channel.Items1")});
            this.comboBox_channel.Name = "comboBox_channel";
            resources.ApplyResources(this.comboBox_channel, "comboBox_channel");
            this.comboBox_channel.SelectedIndexChanged += new System.EventHandler(this.ComboBox_channel_SelectedIndexChanged_1);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // ComboBox_BC
            // 
            this.ComboBox_BC.Items.AddRange(new object[] {
            resources.GetString("ComboBox_BC.Items"),
            resources.GetString("ComboBox_BC.Items1")});
            this.ComboBox_BC.Name = "ComboBox_BC";
            resources.ApplyResources(this.ComboBox_BC, "ComboBox_BC");
            // 
            // ComboBox_BCLX
            // 
            this.ComboBox_BCLX.Items.AddRange(new object[] {
            resources.GetString("ComboBox_BCLX.Items"),
            resources.GetString("ComboBox_BCLX.Items1")});
            this.ComboBox_BCLX.Name = "ComboBox_BCLX";
            resources.ApplyResources(this.ComboBox_BCLX, "ComboBox_BCLX");
            // 
            // button_BC
            // 
            this.button_BC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.button_BC, "button_BC");
            this.button_BC.Name = "button_BC";
            this.button_BC.Click += new System.EventHandler(this.Button_BC_Click);
            // 
            // button_LCW
            // 
            this.button_LCW.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.button_LCW, "button_LCW");
            this.button_LCW.Name = "button_LCW";
            this.button_LCW.Click += new System.EventHandler(this.Button_LCW_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            resources.ApplyResources(this.toolStripSeparator3, "toolStripSeparator3");
            // 
            // SJFX
            // 
            this.SJFX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.SJFX, "SJFX");
            this.SJFX.Name = "SJFX";
            this.SJFX.Click += new System.EventHandler(this.SJFX_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            resources.ApplyResources(this.toolStripSeparator4, "toolStripSeparator4");
            // 
            // button_TJ
            // 
            this.button_TJ.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.button_TJ, "button_TJ");
            this.button_TJ.Name = "button_TJ";
            this.button_TJ.Click += new System.EventHandler(this.Button_TJ_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            resources.ApplyResources(this.toolStripSeparator2, "toolStripSeparator2");
            // 
            // button_Help
            // 
            this.button_Help.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            resources.ApplyResources(this.button_Help, "button_Help");
            this.button_Help.Name = "button_Help";
            this.button_Help.Click += new System.EventHandler(this.Button_Help_Click);
            // 
            // sfd
            // 
            resources.ApplyResources(this.sfd, "sfd");
            this.sfd.FilterIndex = 0;
            this.sfd.RestoreDirectory = true;
            this.sfd.FileOk += new System.ComponentModel.CancelEventHandler(this.SaveFileDialog1_FileOk);
            // 
            // groupBox_param
            // 
            this.groupBox_param.Controls.Add(this.lbxInfo);
            this.groupBox_param.Controls.Add(this.label_baud);
            this.groupBox_param.Controls.Add(this.comboBox_baud);
            this.groupBox_param.Controls.Add(this.textBox_remoteport);
            this.groupBox_param.Controls.Add(this.label_remoteport);
            this.groupBox_param.Controls.Add(this.textBox_remoteaddr);
            this.groupBox_param.Controls.Add(this.label_remoteaddr);
            this.groupBox_param.Controls.Add(this.button_reset);
            this.groupBox_param.Controls.Add(this.button_init);
            this.groupBox_param.Controls.Add(this.button_start);
            this.groupBox_param.Controls.Add(this.textBox_localport);
            this.groupBox_param.Controls.Add(this.label_localport);
            this.groupBox_param.Controls.Add(this.label_netmode);
            this.groupBox_param.Controls.Add(this.button_open);
            this.groupBox_param.Controls.Add(this.comboBox_netmode);
            this.groupBox_param.Controls.Add(this.label_endid);
            this.groupBox_param.Controls.Add(this.textBox_endid);
            this.groupBox_param.Controls.Add(this.label_startid);
            this.groupBox_param.Controls.Add(this.textBox_startid);
            this.groupBox_param.Controls.Add(this.comboBox_mode);
            this.groupBox_param.Controls.Add(this.label_mode);
            resources.ApplyResources(this.groupBox_param, "groupBox_param");
            this.groupBox_param.Name = "groupBox_param";
            this.groupBox_param.TabStop = false;
            // 
            // lbxInfo
            // 
            this.lbxInfo.FormattingEnabled = true;
            resources.ApplyResources(this.lbxInfo, "lbxInfo");
            this.lbxInfo.Name = "lbxInfo";
            // 
            // label_baud
            // 
            resources.ApplyResources(this.label_baud, "label_baud");
            this.label_baud.Name = "label_baud";
            // 
            // comboBox_baud
            // 
            this.comboBox_baud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_baud.FormattingEnabled = true;
            this.comboBox_baud.Items.AddRange(new object[] {
            resources.GetString("comboBox_baud.Items"),
            resources.GetString("comboBox_baud.Items1"),
            resources.GetString("comboBox_baud.Items2"),
            resources.GetString("comboBox_baud.Items3"),
            resources.GetString("comboBox_baud.Items4"),
            resources.GetString("comboBox_baud.Items5"),
            resources.GetString("comboBox_baud.Items6"),
            resources.GetString("comboBox_baud.Items7"),
            resources.GetString("comboBox_baud.Items8"),
            resources.GetString("comboBox_baud.Items9"),
            resources.GetString("comboBox_baud.Items10")});
            resources.ApplyResources(this.comboBox_baud, "comboBox_baud");
            this.comboBox_baud.Name = "comboBox_baud";
            // 
            // textBox_remoteport
            // 
            resources.ApplyResources(this.textBox_remoteport, "textBox_remoteport");
            this.textBox_remoteport.Name = "textBox_remoteport";
            // 
            // label_remoteport
            // 
            resources.ApplyResources(this.label_remoteport, "label_remoteport");
            this.label_remoteport.Name = "label_remoteport";
            // 
            // textBox_remoteaddr
            // 
            resources.ApplyResources(this.textBox_remoteaddr, "textBox_remoteaddr");
            this.textBox_remoteaddr.Name = "textBox_remoteaddr";
            // 
            // label_remoteaddr
            // 
            resources.ApplyResources(this.label_remoteaddr, "label_remoteaddr");
            this.label_remoteaddr.Name = "label_remoteaddr";
            // 
            // button_reset
            // 
            resources.ApplyResources(this.button_reset, "button_reset");
            this.button_reset.Name = "button_reset";
            this.button_reset.UseVisualStyleBackColor = true;
            this.button_reset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // button_init
            // 
            resources.ApplyResources(this.button_init, "button_init");
            this.button_init.Name = "button_init";
            this.button_init.UseVisualStyleBackColor = true;
            this.button_init.Click += new System.EventHandler(this.Button_init_Click);
            // 
            // button_start
            // 
            resources.ApplyResources(this.button_start, "button_start");
            this.button_start.Name = "button_start";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.Button_start_Click);
            // 
            // textBox_localport
            // 
            resources.ApplyResources(this.textBox_localport, "textBox_localport");
            this.textBox_localport.Name = "textBox_localport";
            // 
            // label_localport
            // 
            resources.ApplyResources(this.label_localport, "label_localport");
            this.label_localport.Name = "label_localport";
            // 
            // label_netmode
            // 
            resources.ApplyResources(this.label_netmode, "label_netmode");
            this.label_netmode.Name = "label_netmode";
            // 
            // button_open
            // 
            resources.ApplyResources(this.button_open, "button_open");
            this.button_open.Name = "button_open";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.Button_open_Click_1);
            // 
            // comboBox_netmode
            // 
            this.comboBox_netmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_netmode.FormattingEnabled = true;
            this.comboBox_netmode.Items.AddRange(new object[] {
            resources.GetString("comboBox_netmode.Items"),
            resources.GetString("comboBox_netmode.Items1")});
            resources.ApplyResources(this.comboBox_netmode, "comboBox_netmode");
            this.comboBox_netmode.Name = "comboBox_netmode";
            this.comboBox_netmode.SelectedIndexChanged += new System.EventHandler(this.ComboBox_netmode_SelectedIndexChanged);
            // 
            // label_endid
            // 
            resources.ApplyResources(this.label_endid, "label_endid");
            this.label_endid.Name = "label_endid";
            // 
            // textBox_endid
            // 
            resources.ApplyResources(this.textBox_endid, "textBox_endid");
            this.textBox_endid.Name = "textBox_endid";
            // 
            // label_startid
            // 
            resources.ApplyResources(this.label_startid, "label_startid");
            this.label_startid.Name = "label_startid";
            // 
            // textBox_startid
            // 
            resources.ApplyResources(this.textBox_startid, "textBox_startid");
            this.textBox_startid.Name = "textBox_startid";
            // 
            // comboBox_mode
            // 
            this.comboBox_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_mode.FormattingEnabled = true;
            this.comboBox_mode.Items.AddRange(new object[] {
            resources.GetString("comboBox_mode.Items"),
            resources.GetString("comboBox_mode.Items1")});
            resources.ApplyResources(this.comboBox_mode, "comboBox_mode");
            this.comboBox_mode.Name = "comboBox_mode";
            // 
            // label_mode
            // 
            resources.ApplyResources(this.label_mode, "label_mode");
            this.label_mode.Name = "label_mode";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listView1);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_numLR,
            this.column_time,
            this.column_FX,
            this.column_GS,
            this.column_LX,
            this.column_DLC,
            this.column_zID,
            this.column_channel,
            this.column_DATA});
            resources.ApplyResources(this.listView1, "listView1");
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Name = "listView1";
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.ListView1_SelectedIndexChanged);
            // 
            // column_numLR
            // 
            resources.ApplyResources(this.column_numLR, "column_numLR");
            // 
            // column_time
            // 
            resources.ApplyResources(this.column_time, "column_time");
            // 
            // column_FX
            // 
            resources.ApplyResources(this.column_FX, "column_FX");
            // 
            // column_GS
            // 
            resources.ApplyResources(this.column_GS, "column_GS");
            // 
            // column_LX
            // 
            this.column_LX.Tag = "";
            resources.ApplyResources(this.column_LX, "column_LX");
            // 
            // column_DLC
            // 
            resources.ApplyResources(this.column_DLC, "column_DLC");
            // 
            // column_zID
            // 
            resources.ApplyResources(this.column_zID, "column_zID");
            // 
            // column_channel
            // 
            resources.ApplyResources(this.column_channel, "column_channel");
            // 
            // column_DATA
            // 
            resources.ApplyResources(this.column_DATA, "column_DATA");
            // 
            // button_Test
            // 
            resources.ApplyResources(this.button_Test, "button_Test");
            this.button_Test.Name = "button_Test";
            this.button_Test.UseVisualStyleBackColor = true;
            this.button_Test.Click += new System.EventHandler(this.Button_Test_Click_1);
            // 
            // button_clear1
            // 
            resources.ApplyResources(this.button_clear1, "button_clear1");
            this.button_clear1.Name = "button_clear1";
            this.button_clear1.UseVisualStyleBackColor = true;
            this.button_clear1.Click += new System.EventHandler(this.Button_clear_Click);
            // 
            // tmrRead
            // 
            this.tmrRead.Interval = 50;
            this.tmrRead.Tick += new System.EventHandler(this.TmrRead_Tick);
            // 
            // timerSend
            // 
            this.timerSend.Interval = 2000;
            this.timerSend.Tick += new System.EventHandler(this.TimerSend_Tick);
            // 
            // timer_status
            // 
            this.timer_status.Interval = 2000;
            this.timer_status.Tick += new System.EventHandler(this.Timer1_Tick_1);
            // 
            // button_TestJX
            // 
            resources.ApplyResources(this.button_TestJX, "button_TestJX");
            this.button_TestJX.Name = "button_TestJX";
            this.button_TestJX.UseVisualStyleBackColor = true;
            this.button_TestJX.Click += new System.EventHandler(this.Button_TestJX_Click);
            // 
            // button_FZ
            // 
            resources.ApplyResources(this.button_FZ, "button_FZ");
            this.button_FZ.Name = "button_FZ";
            this.button_FZ.UseVisualStyleBackColor = true;
            this.button_FZ.Click += new System.EventHandler(this.Button_FZ_Click);
            // 
            // timerFZ
            // 
            this.timerFZ.Interval = 1000;
            this.timerFZ.Tick += new System.EventHandler(this.TimerFZ_Tick);
            // 
            // ofdFZ
            // 
            this.ofdFZ.FileName = "openFileDialog1";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // SCADA
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_FZ);
            this.Controls.Add(this.button_TestJX);
            this.Controls.Add(this.button_Test);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_clear1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox_param);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel2);
            this.Name = "SCADA";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SCADA_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SCADA_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox_param.ResumeLayout(false);
            this.groupBox_param.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton button_BC;
        private System.Windows.Forms.ToolStripButton button_Help;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelBuf;
        private System.Windows.Forms.Label labelDATA;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.GroupBox groupBox_param;
        private System.Windows.Forms.Label label_baud;
        private System.Windows.Forms.ComboBox comboBox_baud;
        private System.Windows.Forms.TextBox textBox_remoteport;
        private System.Windows.Forms.Label label_remoteport;
        private System.Windows.Forms.TextBox textBox_remoteaddr;
        private System.Windows.Forms.Label label_remoteaddr;
        private System.Windows.Forms.TextBox textBox_localport;
        private System.Windows.Forms.Label label_localport;
        private System.Windows.Forms.Label label_netmode;
        private System.Windows.Forms.ComboBox comboBox_netmode;
        private System.Windows.Forms.Label label_endid;
        private System.Windows.Forms.TextBox textBox_endid;
        private System.Windows.Forms.Label label_startid;
        private System.Windows.Forms.TextBox textBox_startid;
        private System.Windows.Forms.ComboBox comboBox_mode;
        private System.Windows.Forms.Label label_mode;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripMenuItem label_device;
        private System.Windows.Forms.ToolStripComboBox comboBox_device;
        private System.Windows.Forms.ToolStripMenuItem label_index;
        private System.Windows.Forms.ToolStripComboBox comboBox_index;
        private System.Windows.Forms.ToolStripMenuItem label_channel;
        private System.Windows.Forms.ToolStripComboBox comboBox_channel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader column_numLR;
        private System.Windows.Forms.ColumnHeader column_time;
        private System.Windows.Forms.ColumnHeader column_FX;
        private System.Windows.Forms.ColumnHeader column_GS;
        private System.Windows.Forms.ColumnHeader column_LX;
        private System.Windows.Forms.ColumnHeader column_DLC;
        private System.Windows.Forms.ColumnHeader column_zID;
        private System.Windows.Forms.ToolStripComboBox ComboBox_BC;
        private System.Windows.Forms.ToolStripButton button_LCW;
        private System.Windows.Forms.ColumnHeader column_channel;
        private System.Windows.Forms.ColumnHeader column_DATA;
        private System.Windows.Forms.Button button_Test;
        private System.Windows.Forms.Button button_clear1;
        private System.Windows.Forms.Button button_init;
        private System.Windows.Forms.Button button_reset;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.ListBox lbxInfo;
        private System.Windows.Forms.Timer tmrRead;
        private System.Windows.Forms.Label labRx;
        private System.Windows.Forms.Label labErrInfo1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Timer timerSend;
        private System.Windows.Forms.Timer timer_status;
        private System.Windows.Forms.ToolStripComboBox ComboBox_BCLX;
        private System.Windows.Forms.Button button_TestJX;
        private System.Windows.Forms.Button button_FZ;
        private System.Windows.Forms.Timer timerFZ;
        private System.Windows.Forms.OpenFileDialog ofdFZ;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripButton SJFX;
        private System.Windows.Forms.ToolStripButton button_TJ;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    }
}

