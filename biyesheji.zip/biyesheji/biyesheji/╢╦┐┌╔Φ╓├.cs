﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZLGCAN;

namespace biyesheji
{
    public partial class 端口设置 : Form
    {
        public 端口设置()
        {
            InitializeComponent();
        }

        private void 端口设置_Load(object sender, EventArgs e)
        {
 
 
        }

        private void 打开_Click(object sender, EventArgs e)
        {

            DialogResult = DialogResult.OK;
        }

        private void 取消_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void 网络连接_MouseClick(object sender, MouseEventArgs e)
        {
            网络连接.Checked = true;
            USB连接.Checked = false;
            textBox网络.Enabled = true;
            搜索.Enabled = true;
            comboBox1.Enabled = false;
            刷新.Enabled = false;
        }

        private void USB连接_MouseClick(object sender, MouseEventArgs e)
        {
            网络连接.Checked = false;
            USB连接.Checked = true;
            textBox网络.Enabled = false;
            搜索.Enabled = false;
            comboBox1.Enabled = true;
            刷新.Enabled = true;
        }

      
    }
}
