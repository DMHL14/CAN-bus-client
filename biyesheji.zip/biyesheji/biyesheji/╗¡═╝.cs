﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace biyesheji
{
    public partial class 画图 : Form
    {

        public 画图()
        {
            InitializeComponent();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void 画图_Load(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.Title = "序号";
            chart1.ChartAreas[0].AxisY.Title = "速度（km/h）";

        }

        private void Button_paint_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Convert.ToInt32(解析.num); i++)
            {
                chart1.Series[i].Points.Clear();
            }

            for (int i = 0; i < 解析.XuHao.Count; )
            {
                for (int j = 0; j < Convert.ToInt32(解析.num); j++)//datavalue里面装的是 [第一条报文：信号1，信号2...，第二条报文：信号1，信号2...]
                {
                    chart1.Series[j].Points.AddXY(解析.XuHao[i], 解析.datavalue1[i+j]);
                }
                i =i+ Convert.ToInt32(解析.num);
            }
        }

     

        private void BC_Click(object sender, EventArgs e)
        {
            string fullFileName = Application.StartupPath.Trim() +"仿真实验" + ".png";
            chart1.SaveImage(fullFileName, ChartImageFormat.Png);
            MessageBox.Show("保存成功！","提示");
        }
    }
}
